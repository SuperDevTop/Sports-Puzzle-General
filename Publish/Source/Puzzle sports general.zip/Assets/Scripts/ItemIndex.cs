using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemIndex : MonoBehaviour
{
    public int itemInfo;
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
