using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImageIndex : MonoBehaviour
{
    public int imageInfo;
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
